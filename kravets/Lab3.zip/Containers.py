from abc import ABC, abstractmethod
from uuid import uuid4


class IContainer(ABC):
    @abstractmethod
    def consumption(self) -> float:
        pass


class Container(IContainer):
    def __init__(self, mode: str, weight: float) -> None:
        self.id = uuid4()
        self.weight = weight
        self.container = CreateContainer.create_container(mode, weight)

    def consumption(self) -> float:
        pass

    def __eq__(self, other):
        if other is not None:
            id_check = self.id == other.id
            weight_check = self.weight == other.weight
            type_check = self.__class__ == other.__class__
            if weight_check and type_check and id_check:
                return True
            else:
                return False
        else:
            return False


class CreateContainer(Container):
    @staticmethod
    def create_container(container_type="B", weight=0):
        if weight <= 3000 and container_type == "B":
            return BasicContainer(weight)
        else:
            if container_type == "H":
                return HevyContainer(weight)
            elif container_type == "R":
                return RefrigiratorContainer(weight)
            elif container_type == "L":
                return LiquidContainer(weight)
            else:
                print("Invalid container type")


class BasicContainer(Container):
    def __init__(self, weight: float) -> None:
        self.weight = weight
        self.id = uuid4()

    def consumption(self) -> float:
        return self.weight * 2.5


class HevyContainer(Container):
    def __init__(self, weight: float) -> None:
        self.weight = weight
        self.id = uuid4()

    def consumption(self) -> float:
        return self.weight * 3.0


class RefrigiratorContainer(HevyContainer):
    def __init__(self, weight: float) -> None:
        self.weight = weight
        self.id = uuid4()

    def consumption(self) -> float:
        return self.weight * 5.0


class LiquidContainer(HevyContainer):
    def __init__(self, weight: float) -> None:
        self.weight = weight
        self.id = uuid4()

    def consumption(self) -> float:
        return self.weight * 4.0

