from abc import ABC, abstractmethod
from uuid import uuid4
from dataclass import dataclasses

@dataclasses
class ConfigItem:
    weight:float
    container_id:str
    amount: int
    type: str



class IItem(ABC):
    def __init__(self, config_item: ConfigItem ):
        pass
    def getWeight(self):
        pass

class CreateItem(Item):
    def CreateItem(self,item: Item):
        if item.getWeight() <100:
            return SmallItem(item)
        else:
            if item.config_item.type == 'B':
                return LargeItem()
            elif item.config_item.type == 'l':
                return LiquidItem()
            elif item.config_item.type == 'R':
                return RefrigiratedItem()

    pass

class Item(IItem):
    def __init__(self, config_item: ConfigItem):
        self.id=uuid4()
        self.weight = config_item.weight
        self.amount = config_item.amount
    def getWeight(self):
        return self.weight
    pass

class SmallItem(Item):
    def __init__(self, weight):
        self.weight = weight
    def getWeight(self):
        return weight
    pass


class LargeItem(Item):
    def __init__(self, weight):
        self.weight = weight
    def getWeight(self):
        return weight
    pass

class RefrigiratedItem(LargeItem):
    def __init__(self, weight):
        self.weight = weight
    def getWeight(self):
        return weight
    pass

class LiquidItem(LargeItem):
    def __init__(self, weight):
        self.weight = weight
    def getWeight(self):
        return weight
    pass
