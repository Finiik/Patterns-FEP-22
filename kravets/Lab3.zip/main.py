import json
from icecream import ic

import Containers
from Port import Port, ConfigPort
from Ship import Ship, ConfigShip
from Containers import Container
with open("input.json", "r") as f:
    data = json.load(f)
confdata = []
ports = []
ships = []
basic_containers = []
heavy_containers = []
refrigirator_containers = []
liquid_containers = []
current_port: Port
current_ship: Ship




confdata.append(data)

#placing all ports fom json into ports list
for i in confdata:
    for j in i:
      ports.append(Port(ConfigPort(**j)))

#__________________________
#ERROR
#__________________________
#placing all ships from json into ships list
for i in ports:
    ic(i)
    for j in i.config_port.ships:
        ic(j)
        i.ships.append(Ship(ConfigShip(*j)))


    ports[0].get_ships()
    ports[1].get_ships()
    ports[0].ships[0].sail_to(ports[0], ports[1])
    ports[0].get_ships()
    ports[1].get_ships()
    container = ports[0].create_container('B', 100)
    ports[0].create_container('H', 4000)
    ports[0].create_container('R', 4000)
    ports[0].create_container('L', 4000)
    ports[0].create_container('B', 100)


    ports[0].ships[0].load(ports[0].basic_containers[0], ports[0])
    ships[0].sail_to(ports[0], ports[1])
    ships[0].unload(container.id, ports[1])


    x=[]
    for port in ports:
      x.append({
          "Port": f"{port.port_id}",
          "Longitude": f"{port.config_port.longitude}",
          "Latitude": f"{port.config_port.latitude}",
          "Basic_containers": f"{port.basic_containers}",
          "Heavy_containers": f"{port.heavy_containers}",
          "liquid_containers": f"{port.liquid_containers}",
          "Refgirigerated_containers": f"{port.refrigirator_containers}",
          "Ships": [
              {
                  "ship": f"{port.ships[0].ship_config.ship_id}",
                  "fuel": f"{port.ships[0].fuel}",
                  "Basic_containers": f"{port.ships[0].containers}",
               }
              ]

      })

    print(json.dumps(x[0]))
